<?php

namespace Controlscan\Hpf\Block;

use Magento\Framework\App\Config\ScopeConfigInterface;

class Hpf extends \Magento\Framework\View\Element\Template /*\Magento\Config\Block\System\Config\Form\Field */
{
	
	 protected $Config;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $_orderFactory;

    /**
     * @var \Magento\Sales\Model\Order\Config
     */
    protected $_orderConfig;

    /**
     * @var \Magento\Framework\App\Http\Context
     */
    protected $httpContext;
	
	
	
	
	
	
	
	/**
     * @var \Controlscan\Hpf\Helper\Data
     */
    protected $_helper;
	
	protected $_moduleManager;
	
	 /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager;
	
	
	 const CONFIG_PATH_API_TOKEN     = 'payment/controlscanhpf/api_token';
	 
	 const CONFIG_PATH_CRE_SECURE_ID = 'payment/controlscanhpf/cre_secure_id';
	 	 
		 
		 public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
		\Magento\Framework\Module\Manager $moduleManager,
		\Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Sales\Model\Order\Config $orderConfig,
        array $data = [],
        \Controlscan\Hpf\Helper\Data $helper,
        \Magento\Framework\ObjectManagerInterface $objectManager
    ) {
        parent::__construct($context, $data);

		$this->_moduleManager = $moduleManager;
        $this->_helper = $helper;
        $this->_objectManager = $objectManager;
        $this->_checkoutSession = $checkoutSession;
        $this->_customerSession = $customerSession;
        $this->_orderFactory = $orderFactory;
        $this->_orderConfig = $orderConfig;
	}
		

	/**
     * Whether a module is enabled in the configuration or not
     *
     * @param string $moduleName Fully-qualified module name
     * @return boolean
     */
	public function isModuleEnabled($moduleName)
	{
		return $this->_moduleManager->isEnabled($moduleName);
	}
	
	/**
     * Whether a module output is permitted by the configuration or not
     *
     * @param string $moduleName Fully-qualified module name
     * @return boolean
     */
    public function isOutputEnabled($moduleName)
    {
		return $this->_moduleManager->isOutputEnabled($moduleName);
	
	} 
		 
   
	
	 public function getPaymentAction(){
        return $this->_helper->getPaymentAction();
    }
	
	
	
		 
	  public function getApiToken()
    {
      return $this->_scopeConfig->getValue(self::CONFIG_PATH_API_TOKEN, \Magento\Store\Model\ScopeInterface::SCOPE_STORE,null);
    
	}
	
	public function getCreSecureId()
    {
      return $this->_scopeConfig->getValue(self::CONFIG_PATH_CRE_SECURE_ID, \Magento\Store\Model\ScopeInterface::SCOPE_STORE,null);
    
	}
	
	
	
	protected function _getElementHtml(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $originalData = $element->getOriginalData();
        $this->addData(
            [
                'api_token' => $originalData['api_token'],
                'cre_secure_id' => $originalData['cre_secure_id'],
				'active_or_not' => $originalData['enable'],
				'debug_mode' => $originalData['debug'],
				'payment_action' => $originalData['payment_action'],
				
                /*'intern_url' => $this->getUrl($originalData['button_url']),
                'load_config_url' => $this->getUrl($originalData['load_config_url']),
                'html_id' => $element->getHtmlId(),*/
            ]
        );
        return $this->_toHtml();
    }
	
	
	
	 public function getAmount()
    {   $orderId = $this->_checkoutSession->getLastOrderId(); 
        if ($orderId) {
            $incrementId = $this->_checkoutSession->getLastRealOrderId();

        return $this->Config->getAmount($incrementId);
    }
    }
}
 
	
	


