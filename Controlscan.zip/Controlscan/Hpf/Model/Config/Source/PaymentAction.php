<?php

namespace Controlscan\Hpf\Model\Config\Source;

use \Magento\Framework\Option\ArrayInterface;

use \Magento\Payment\Model\Method\AbstractMethod;


class PaymentAction implements ArrayInterface
{
	
	/**
     * Options getter
     *
     * @return array
     */
	
   public function toOptionArray()
    {
        return [
            [
                'value' => AbstractMethod::ACTION_AUTHORIZE,
                'label' => __('Authorize'),
            ],
            [
                'value' => AbstractMethod::ACTION_AUTHORIZE_CAPTURE,
                'label' => __('Authorize and Capture'),
            ]
        ];
    }
	
	 /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return ['AUTHORIZE' => __('AUTHORIZE'),
                'AUTHORIZE_CAPTURE' => __('AUTHORIZE_CAPTURE')
        ];
    }
	
	
}