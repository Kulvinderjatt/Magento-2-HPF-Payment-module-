<?php

namespace Controlscan\Hpf\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\Store;
use Magento\Payment\Model\Config as PaymentConfig;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	
	/**
     * @var \Magento\Framework\App\Config\ScopeConfigInterfac
     */
    protected $_scopeConfig;
	
	//CONST ENABLE                  = 'payment/controlscanhpf/enable';
    const CONFIG_PATH_API_TOKEN     = 'payment/controlscanhpf/api_token';
	const CONFIG_PATH_CRE_SECURE_ID = 'payment/controlscanhpf/cre_secure_id';
	CONST PAYMENT_ACTION            = 'payment/controlscanhpf/payment_action';
	

   
    /**
     * @var PaymentConfig
     */
    protected $paymentConfig;

    /**
     * @param Context $context
     * @param PaymentConfig $paymentConfig
     
     */
    public function __construct(
	    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        Context $context,
        PaymentConfig $paymentConfig
        
    ) 
	{
        parent::__construct($context);
		
        $this->paymentConfig = $paymentConfig;
		$this->_scopeConfig = $scopeConfig;
        
    }


	 public function getConfig($config_path)
    {
        return $this->scopeConfig->getValue(
            $config_path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
	
	
    
    public function getApiToken()
    {
        return $this->scopeConfig->getValue(self::CONFIG_PATH_API_TOKEN);
    }

     public function getCreSecureId()
    {
		$accountId = $this->scopeConfig->getValue(self::CONFIG_PATH_CRE_SECURE_ID, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $store);
        return $accountId;
    }

   
	
	public function getPaymentAction(){
        return $this->_scopeConfig->getValue(self::PAYMENT_ACTION);
    }
	
}
