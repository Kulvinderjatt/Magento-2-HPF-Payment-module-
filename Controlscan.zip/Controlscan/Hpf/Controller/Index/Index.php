<?php

namespace Controlscan\Hpf\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action {
	
    protected $resultPageFactory;
  
    public function __construct(
	   \Magento\Framework\App\Action\Context $context,

        \Magento\Framework\View\Result\PageFactory $resultPageFactory
		)     
		{
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);

        }
	
	public function execute()

	{
		//$this->getResponse()->appendBody('Hello world');

		return $this->resultPageFactory->create();
		
		$config = $this->_objectManager->get('Controlscan\Hpf\Helper\Data')->getConfig('payment/controlscanhpf/api_token');
		
		echo $config;
		
		/*echo "<br> hi".$this->getConfig('payment/controlscanhpf/api_token');*/
			
		
		//load model
        /* @var $paymentMethod \Magento\Authorizenet\Model\DirectPost */
        $paymentMethod = $this->_objectManager->create('Controlscan\Hpf\Model\Hpf');

        //get request data
        $data = $this->getRequest()->getPostValue();

        $paymentMethod->process($data);
        //return $this->resultPageFactory->create();
		

	}

}